@file:OptIn(ExperimentalMaterial3Api::class)
package com.altecoffee.staff

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

private val PixelEase = CubicBezierEasing(0.2f, 0f, 0f, 1f)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AlteTheme { App() } }
    }
}

@Composable
fun AlteTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current; val dark = isSystemInDarkTheme()
    val cs = if (Build.VERSION.SDK_INT >= 31) { if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx) }
    else if (dark) darkColorScheme(primary = Color(0xFFD7B38A)) else lightColorScheme(primary = Color(0xFF7A4B2A))
    MaterialTheme(colorScheme = cs, shapes = Shapes(large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(32.dp)), content = content)
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf<Coffee?>(null) }
    var last by remember { mutableStateOf<Coffee?>(null) }
    if (sel != null) last = sel
    BackHandler(sel != null) { sel = null }
    Box(Modifier.fillMaxSize()) {
        Scaffold(bottomBar = {
            NavigationBar {
                listOf("Меню" to "☕", "Что сегодня?" to "🎲").forEachIndexed { i, (t, e) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(e, fontSize = 22.sp) }, label = { Text(t) })
                }
            }
        }) { pad ->
            AnimatedContent(tab, transitionSpec = {
                (fadeIn(tween(350, easing = PixelEase)) + slideInHorizontally(tween(450, easing = PixelEase)) { if (targetState > initialState) it / 6 else -it / 6 }) togetherWith fadeOut(tween(150))
            }, label = "tab") { t -> if (t == 0) MenuScreen(pad) { sel = it } else RandomScreen(pad) { sel = it } }
        }
        AnimatedVisibility(sel != null,
            enter = slideInVertically(spring(0.85f, Spring.StiffnessMediumLow)) { it / 4 } + fadeIn() + scaleIn(initialScale = 0.92f),
            exit = slideOutVertically(tween(250, easing = PixelEase)) { it / 6 } + fadeOut(tween(200)) + scaleOut(targetScale = 0.95f)) {
            last?.let { DetailScreen(it) { sel = null } }
        }
    }
}

@Composable
fun MenuScreen(pad: PaddingValues, open: (Coffee) -> Unit) {
    var q by remember { mutableStateOf("") }; var cat by remember { mutableStateOf("Все") }
    val cats = listOf("Все", "Классика", "Молочные", "Холодные", "Сиропы", "Топпинги", "Посыпки", "Сладкое", "Сгущёнка", "Мёд", "Алкоголь")
    val list = remember(q, cat) {
        Menu.filter { (cat == "Все" || cat in it.tags) && (q.isBlank() || it.name.contains(q, true) || it.ings.any { x -> x.name.contains(q, true) }) }
    }
    val sb = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    Column(Modifier.fillMaxSize().nestedScroll(sb.nestedScrollConnection)) {
        LargeTopAppBar(title = { Text("AlteCoffee ☕", fontWeight = FontWeight.Bold) }, scrollBehavior = sb)
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, pad.calculateBottomPadding() + 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                TextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Поиск: напиток или ингредиент") }, singleLine = true, shape = CircleShape,
                    colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(cats) { FilterChip(selected = cat == it, onClick = { cat = it }, label = { Text(it) }) }
                    }
                    Text("${list.size} напитков", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.outline)
                }
            }
            items(list, key = { it.id }) { c -> CoffeeCard(c, Modifier.animateItem()) { open(c) } }
        }
    }
}

@Composable
fun CoffeeCard(c: Coffee, mod: Modifier, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }; val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.95f else 1f, spring(0.6f, 400f), label = "press")
    val tint = c.top ?: c.layers.last()
    Card(onClick, mod.graphicsLayer { scaleX = sc; scaleY = sc }, interactionSource = src,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Box(Modifier.fillMaxWidth().height(130.dp).background(Brush.verticalGradient(listOf(tint.copy(.35f), tint.copy(.08f))))) {
            CupArt(c, Modifier.align(Alignment.Center).size(104.dp))
            Text(c.emoji, Modifier.align(Alignment.TopEnd).padding(10.dp), fontSize = 20.sp)
        }
        Column(Modifier.padding(12.dp)) {
            Text(c.name, maxLines = 2, minLines = 2, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("${c.base} · ${c.vol[0]}/${c.vol[1]}/${c.vol[2]} мл", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline, maxLines = 1)
        }
    }
}

@Composable
fun CupArt(c: Coffee, mod: Modifier) {
    val t = rememberInfiniteTransition(label = "steam")
    val st by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "s")
    Canvas(mod) {
        val w = size.width; val h = size.height
        val top = h * 0.30f; val bot = h * 0.92f; val l = w * 0.22f; val r = w * 0.78f; val inset = w * 0.06f
        val glass = Path().apply { moveTo(l, top); lineTo(r, top); lineTo(r - inset, bot); lineTo(l + inset, bot); close() }
        drawPath(glass, Color.White.copy(.35f))
        clipPath(glass) {
            val lh = (bot - top) * 0.85f / c.layers.size; var y = bot
            c.layers.forEach { col -> drawRect(col, Offset(0f, y - lh), Size(w, lh)); y -= lh }
        }
        drawPath(glass, Color.Black.copy(.25f), style = Stroke(width = w * 0.03f))
        c.top?.let { for (k in 0..4) drawCircle(it, w * 0.035f, Offset(l + w * 0.08f + k * (r - l - w * .16f) / 4f, top + h * 0.05f + (k % 2) * h * 0.03f)) }
        if (c.cold) { for (k in 0..1) drawRoundRect(Color.White.copy(.55f), Offset(l + w * (0.12f + 0.2f * k), top + h * 0.12f + k * h * 0.05f), Size(w * 0.12f, w * 0.12f), CornerRadius(6f)) }
        else for (k in 0..2) {
            val p = (st + k / 3f) % 1f
            drawCircle(Color.White.copy(.55f * (1 - p)), w * 0.03f + p * w * 0.03f, Offset(w * (0.38f + 0.12f * k) + sin(p * 6.28f) * w * 0.03f, top - p * h * 0.25f))
        }
    }
}

@Composable
fun Stagger(i: Int, content: @Composable () -> Unit) {
    var v by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(80L * i + 150); v = true }
    AnimatedVisibility(v, enter = fadeIn(tween(350)) + slideInVertically(tween(450, easing = PixelEase)) { it / 3 }) { content() }
}

@Composable
fun DetailScreen(c: Coffee, back: () -> Unit) {
    var size by remember(c) { mutableIntStateOf(1) }
    val tint = c.top ?: c.layers.last()
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
            item {
                Box(Modifier.fillMaxWidth().height(300.dp).background(Brush.verticalGradient(listOf(tint.copy(.45f), MaterialTheme.colorScheme.surface)))) {
                    CupArt(c, Modifier.align(Alignment.Center).size(230.dp))
                    FilledTonalIconButton(onClick = back, modifier = Modifier.statusBarsPadding().padding(12.dp)) { Text("←", fontSize = 20.sp) }
                }
            }
            item {
                Column(Modifier.padding(horizontal = 20.dp)) {
                    Text(c.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(c.tags.joinToString(" · "), color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 6.dp))
                    Spacer(Modifier.height(8.dp))
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        listOf("S", "M", "L").forEachIndexed { k, n ->
                            SegmentedButton(size == k, { size = k }, SegmentedButtonDefaults.itemShape(k, 3)) { Text("$n · ${c.vol[k]} мл") }
                        }
                    }
                    Text("Ингредиенты", Modifier.padding(top = 20.dp, bottom = 8.dp), style = MaterialTheme.typography.titleLarge)
                }
            }
            itemsIndexed(c.ings) { idx, ing ->
                Stagger(idx) {
                    Surface(Modifier.padding(horizontal = 20.dp, vertical = 4.dp).fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                        Row(Modifier.padding(16.dp, 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(ing.name, Modifier.weight(1f))
                            AnimatedContent(size, transitionSpec = { (slideInVertically { it } + fadeIn()) togetherWith (slideOutVertically { -it } + fadeOut()) }, label = "amt") { s ->
                                Text(ing.text(s), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
            item {
                Column(Modifier.padding(20.dp)) {
                    Text("Приготовление", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 8.dp))
                    c.steps.forEachIndexed { k, s -> Text("${k + 1}. $s", Modifier.padding(vertical = 3.dp)) }
                    if (c.alcohol) Surface(Modifier.padding(top = 16.dp).fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.errorContainer) {
                        Text("🔞 Содержит алкоголь. Подавать только гостям 18+.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
        }
    }
}

@Composable
fun RandomScreen(pad: PaddingValues, open: (Coffee) -> Unit) {
    var mode by remember { mutableStateOf("Любой") }
    var cur by remember { mutableStateOf<Coffee?>(null) }
    var spin by remember { mutableStateOf(false) }
    var ticker by remember { mutableStateOf("") }
    val rot = remember { Animatable(0f) }; val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(bottom = pad.calculateBottomPadding()).statusBarsPadding().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Что сегодня готовим?", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        LazyRow(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("Любой", "Горячий", "Холодный", "Без алкоголя")) { FilterChip(mode == it, { mode = it }, label = { Text(it) }) }
        }
        Spacer(Modifier.weight(1f))
        AnimatedContent(if (spin) null else cur, transitionSpec = { (scaleIn(spring(0.55f, 300f), initialScale = 0.7f) + fadeIn()) togetherWith fadeOut(tween(100)) }, label = "rnd") { c ->
            if (c == null) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🎲", Modifier.graphicsLayer { rotationZ = rot.value }, fontSize = 96.sp)
                Text(if (spin) ticker else "Нажмите «Крутить»", Modifier.padding(top = 16.dp), style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
            } else Card({ open(c) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    CupArt(c, Modifier.size(180.dp))
                    Text(c.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text("Нажмите, чтобы открыть рецепт", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = {
            if (!spin) scope.launch {
                val pool = Menu.filter { when (mode) { "Горячий" -> !it.cold; "Холодный" -> it.cold; "Без алкоголя" -> !it.alcohol; else -> true } }
                spin = true
                launch { rot.animateTo(rot.value + 720f, tween(1500, easing = FastOutSlowInEasing)) }
                repeat(14) { ticker = pool.random().name; delay(70L + it * 20L) }
                cur = pool.random(); spin = false
            }
        }, Modifier.fillMaxWidth().height(64.dp)) { Text(if (cur == null) "Крутить 🎲" else "Ещё раз 🎲", style = MaterialTheme.typography.titleMedium) }
    }
}
