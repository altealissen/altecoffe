package com.altecoffee.staff

import androidx.compose.ui.graphics.Color

data class Ing(val name: String, val s: Double, val m: Double, val l: Double, val unit: String) {
    fun text(i: Int): String {
        val a = listOf(s, m, l)[i]
        return (if (a % 1.0 == 0.0) a.toInt().toString() else a.toString()) + " " + unit
    }
}

data class Coffee(
    val id: Int, val name: String, val base: String, val emoji: String, val tags: Set<String>,
    val vol: List<Int>, val ings: List<Ing>, val steps: List<String>, val layers: List<Color>,
    val top: Color?, val cold: Boolean, val alcohol: Boolean
)

private class B(val name: String, val emoji: String, val tag: String, val cold: Boolean, val vol: List<Int>,
                val shots: List<Int>, val ice: Double, val liquid: String, val layers: List<Color>,
                val extra: List<Ing>, val step: String)
private class V(val brand: String, val tags: Set<String>, val top: Color, val emoji: String, val step: String, val ings: List<Ing>)

private val ESP = Color(0xFF3B2416); private val MILK = Color(0xFFE6CDAA); private val FOAM = Color(0xFFF8EEDD)
private val CHOC = Color(0xFF5A3524); private val ORG = Color(0xFFF2A33A); private val TON = Color(0xFFD6E9E4)

private fun i(n: String, s: Int, m: Int, l: Int, u: String = "мл") = Ing(n, s.toDouble(), m.toDouble(), l.toDouble(), u)

private val bases = listOf(
    B("Эспрессо", "☕", "Классика", false, listOf(30, 60, 90), listOf(1, 2, 3), 0.0, "", listOf(ESP), emptyList(), "Пролейте эспрессо 25–30 секунд в прогретую чашку."),
    B("Американо", "🫖", "Классика", false, listOf(250, 350, 450), listOf(1, 2, 2), 0.0, "", listOf(ESP.copy(alpha = .8f)), emptyList(), "Налейте горячую воду, затем пролейте эспрессо сверху."),
    B("Капучино", "🥛", "Молочные", false, listOf(180, 250, 330), listOf(1, 2, 2), 0.0, "Молоко 3,2%", listOf(ESP, MILK, FOAM), emptyList(), "Взбейте молоко до плотной пены (60–65°C), оставьте шапку 1 см."),
    B("Латте", "🥛", "Молочные", false, listOf(250, 350, 450), listOf(1, 2, 2), 0.0, "Молоко 3,2%", listOf(ESP, MILK, FOAM), emptyList(), "Взбейте молоко в микропену и влейте тонкой струёй."),
    B("Флэт Уайт", "🤍", "Молочные", false, listOf(160, 220, 300), listOf(1, 2, 2), 0.0, "Молоко 3,2%", listOf(ESP, MILK), emptyList(), "Влейте бархатное молоко без толстой пены."),
    B("Кортадо", "🧡", "Молочные", false, listOf(100, 140, 180), listOf(1, 2, 2), 0.0, "Молоко 3,2%", listOf(ESP, MILK), emptyList(), "Эспрессо и тёплое молоко 1:1."),
    B("Макиато", "🤎", "Молочные", false, listOf(90, 130, 170), listOf(1, 2, 2), 0.0, "Молочная пена", listOf(ESP, FOAM), emptyList(), "Поставьте пятно пены на эспрессо."),
    B("Мокка", "🍫", "Молочные", false, listOf(250, 350, 450), listOf(1, 2, 2), 0.0, "Молоко 3,2%", listOf(CHOC, ESP, MILK, FOAM), listOf(i("Шоколадный соус", 15, 20, 30)), "Смешайте соус с эспрессо, добавьте молоко."),
    B("Раф", "🍦", "Молочные", false, listOf(250, 350, 450), listOf(1, 2, 2), 0.0, "Сливки 10%", listOf(ESP, MILK, FOAM), listOf(i("Ванильный сахар", 5, 8, 10, "г")), "Прогрейте сливки паром вместе с ванильным сахаром."),
    B("Айс Латте", "🧊", "Холодные", true, listOf(300, 400, 500), listOf(1, 2, 2), 0.3, "Холодное молоко", listOf(MILK, ESP.copy(alpha = .9f)), emptyList(), "Налейте молоко на лёд, сверху пролейте эспрессо."),
    B("Айс Американо", "🧊", "Холодные", true, listOf(300, 400, 500), listOf(1, 2, 2), 0.35, "", listOf(ESP.copy(alpha = .8f)), emptyList(), "Лёд, холодная вода, сверху эспрессо."),
    B("Бамбл", "🍊", "Холодные", true, listOf(300, 400, 500), listOf(1, 2, 2), 0.3, "Апельсиновый сок", listOf(ORG, ESP), listOf(i("Сироп карамельный", 10, 15, 20)), "Сок со льдом, эспрессо выливайте медленно по ложке."),
    B("Гляссе", "🍨", "Холодные", true, listOf(120, 160, 200), listOf(1, 2, 2), 0.0, "Холодное молоко", listOf(MILK, ESP, FOAM), listOf(i("Пломбир", 60, 90, 120, "г")), "Шарик пломбира в стакан, залейте горячим эспрессо."),
    B("Эспрессо-тоник", "🫧", "Холодные", true, listOf(300, 400, 500), listOf(1, 2, 2), 0.3, "Тоник", listOf(TON, ESP), listOf(i("Лимон (долька)", 1, 2, 2, "шт")), "Тоник на лёд, затем эспрессо по барной ложке.")
)

private fun syr(n: String, b: String, c: Long, e: String) =
    V(b, setOf("Сиропы"), Color(c), e, "Добавьте сироп «$n» (3 помпы S / 4 M / 6 L).", listOf(i("Сироп $n", 15, 20, 30)))
private fun alc(n: String, b: String, e: String, vararg x: Ing) =
    V(b, setOf("Алкоголь"), Color(0xFFC77B30), e, "Влейте «$n» после приготовления. Только гостям 18+.", listOf(i(n, 20, 30, 40)) + x)
private fun top(b: String, t: Set<String>, c: Long, e: String, s: String, vararg x: Ing) = V(b, t, Color(c), e, s, x.toList())

private val variants: List<V> = listOf(
    syr("ванильный", "Ванильное небо", 0xFFF3E0B0, "🍦"), syr("карамельный", "Золотая карамель", 0xFFD98E32, "🍮"),
    syr("лесной орех", "Лесной шёпот", 0xFFB5834F, "🌰"), syr("солёная карамель", "Морская соль", 0xFFE0A85C, "🧂"),
    syr("кокосовый", "Кокосовый бриз", 0xFFF5F0E6, "🥥"), syr("миндальный", "Миндальный рассвет", 0xFFEBD5B3, "🌸"),
    syr("фисташковый", "Изумрудная фисташка", 0xFF9CC77A, "💚"), syr("лавандовый", "Лавандовый закат", 0xFFB59AD9, "💜"),
    syr("имбирный пряник", "Пряничный дом", 0xFFC98B4E, "🍪"), syr("кленовый", "Канадский клён", 0xFFC9792B, "🍁"),
    syr("вишнёвый", "Вишнёвый джаз", 0xFFB3243F, "🍒"), syr("банановый", "Банановый рай", 0xFFF2DC6B, "🍌"),
    syr("попкорн", "Кино-вечер", 0xFFF4E3A0, "🍿"), syr("ирис", "Тоффи-бум", 0xFFC98F4F, "🍬"),
    syr("мятный", "Ледяная мята", 0xFF8FD6B0, "🌿"), syr("клубничный", "Клубничный поцелуй", 0xFFE0577A, "🍓"),
    syr("маракуйя", "Тропический шторм", 0xFFF2B233, "🥭"),
    top("Шоколадный взрыв", setOf("Топпинги", "Посыпки", "Сладкое"), 0xFF4A2A1C, "🍫", "Полейте шоколадным топпингом и посыпьте крошкой.", i("Шоколадный топпинг", 10, 15, 20), i("Шоколадная крошка", 3, 5, 8, "г")),
    top("Карамельное облако", setOf("Топпинги", "Сладкое"), 0xFFD98E32, "🍮", "Взбитые сливки сверху, полейте карамелью.", i("Карамельный топпинг", 10, 15, 20), i("Взбитые сливки", 20, 30, 40, "г")),
    top("Ягодный закат", setOf("Топпинги", "Сладкое"), 0xFFD9507A, "🍓", "Взбитые сливки и клубничный топпинг сверху.", i("Клубничный топпинг", 10, 15, 20), i("Взбитые сливки", 20, 30, 40, "г")),
    top("Зефирный уют", setOf("Посыпки", "Топпинги", "Сладкое"), 0xFFFBE9EF, "☁️", "Маршмеллоу сверху, полейте шоколадом.", i("Маршмеллоу", 3, 5, 7, "шт"), i("Шоколадный топпинг", 8, 12, 16)),
    top("Кокосовый снег", setOf("Посыпки", "Сладкое"), 0xFFFFFFFF, "🥥", "Посыпьте кокосовой стружкой.", i("Кокосовая стружка", 3, 5, 8, "г"), i("Сироп кокосовый", 10, 15, 20)),
    top("Лотус-дрим", setOf("Посыпки", "Топпинги", "Сладкое"), 0xFFC9803A, "🍪", "Карамель и крошка печенья сверху.", i("Крошка печенья Lotus", 5, 8, 10, "г"), i("Карамельный топпинг", 8, 12, 16)),
    top("Арахисовый хит", setOf("Топпинги", "Сладкое"), 0xFFC49A5B, "🥜", "Растворите пасту в эспрессо, украсьте шоколадом.", i("Арахисовая паста", 10, 15, 20, "г"), i("Шоколадный топпинг", 8, 12, 16)),
    top("Ореховый хруст", setOf("Посыпки", "Сладкое"), 0xFFA9743F, "🌰", "Посыпьте дроблёным фундуком.", i("Дроблёный фундук", 4, 6, 8, "г"), i("Сироп лесной орех", 10, 15, 20)),
    top("Сладкая сгущёнка", setOf("Сгущёнка", "Сладкое"), 0xFFF0D9A8, "🥫", "Размешайте сгущёнку с эспрессо до растворения.", i("Сгущённое молоко", 20, 30, 40, "г")),
    top("Детство в чашке", setOf("Сгущёнка", "Посыпки", "Сладкое"), 0xFF9C5A2E, "🥫", "Сгущёнка в эспрессо, сверху щепотка корицы.", i("Сгущённое молоко", 20, 30, 40, "г"), i("Корица", 1, 1, 2, "г")),
    top("Медовый закат", setOf("Мёд", "Сладкое"), 0xFFE6A82B, "🍯", "Растворите мёд в горячем эспрессо.", i("Мёд", 10, 15, 20, "г")),
    top("Медовая корица", setOf("Мёд", "Посыпки"), 0xFFE0A030, "🍯", "Мёд в эспрессо, сверху корица.", i("Мёд", 10, 15, 20, "г"), i("Корица", 1, 1, 2, "г")),
    top("Золотой улей", setOf("Мёд", "Посыпки"), 0xFFEEC25A, "🐝", "Мёд в эспрессо, сверху лепестки миндаля.", i("Мёд", 10, 15, 20, "г"), i("Лепестки миндаля", 3, 5, 7, "г")),
    top("Солнечный мёд", setOf("Мёд"), 0xFFF2C94C, "🍋", "Мёд в эспрессо, добавьте цедру лимона.", i("Мёд", 10, 15, 20, "г"), i("Цедра лимона", 1, 2, 3, "г")),
    top("Пряная корица", setOf("Посыпки"), 0xFF9C5A2E, "🌟", "Посыпьте корицей через трафарет.", i("Корица", 1, 1, 2, "г")),
    top("Бархатное какао", setOf("Посыпки"), 0xFF5A3524, "🤎", "Посыпьте какао-порошком.", i("Какао-порошок", 2, 3, 4, "г")),
    top("Тёплый вечер", setOf("Посыпки", "Сиропы"), 0xFFE8D2A0, "🌙", "Ваниль в чашку, сверху мускатный орех.", i("Сироп ванильный", 10, 15, 20), i("Мускатный орех", 1, 1, 1, "г")),
    alc("Бейлис", "Ирландская сказка", "🍀"), alc("Тёмный ром", "Пиратская ночь", "🏴‍☠️"),
    alc("Виски", "Шотландский туман", "🥃"), alc("Амаретто", "Итальянская ночь", "🇮🇹"),
    alc("Коньяк", "Парижский вечер", "🍷"), alc("Кофейный ликёр", "Мексиканский огонь", "🔥"),
    alc("Бренди", "Старый порт", "⚓"), alc("Тёмный ром", "Карибский шторм", "🌴", i("Корица", 1, 1, 2, "г")),
    alc("Виски", "Медовый виски", "🍯", i("Мёд", 8, 12, 16, "г")), alc("Бейлис", "Шоколадный бейлис", "🍫", i("Шоколадный топпинг", 8, 12, 16))
)

private fun baseIngs(b: B): List<Ing> {
    val sh = b.shots
    val ice = List(3) { (b.vol[it] * b.ice / 5).toInt() * 5 }
    val liq = List(3) { b.vol[it] - sh[it] * 30 - ice[it] }
    val r = mutableListOf(i("Молотый кофе (рожок)", sh[0] * 9, sh[1] * 9, sh[2] * 9, "г"), i("Эспрессо", sh[0] * 30, sh[1] * 30, sh[2] * 30))
    if (liq[0] > 0) r.add(i(if (b.liquid.isEmpty()) (if (b.cold) "Холодная вода" else "Горячая вода") else b.liquid, liq[0], liq[1], liq[2]))
    if (ice[0] > 0) r.add(i("Лёд", ice[0], ice[1], ice[2], "г"))
    return r + b.extra
}

val Menu: List<Coffee> by lazy {
    val out = ArrayList<Coffee>(); var id = 0
    val tintTags = setOf("Сиропы", "Алкоголь", "Мёд", "Сгущёнка")
    for (b in bases) for (v in listOf<V?>(null) + variants) {
        val tags = mutableSetOf(b.tag); if (b.cold) tags.add("Холодные"); if (v != null) tags.addAll(v.tags)
        val tint = v != null && v.tags.any { it in tintTags }
        val layers = if (tint) listOf(v!!.top.copy(alpha = .9f)) + b.layers else b.layers
        val steps = listOfNotNull(
            if (b.cold) "Наполните стакан льдом по рецепту." else "Прогрейте чашку горячей водой.",
            b.step, v?.step, "Проверьте объём по размеру и подайте гостю."
        )
        out.add(Coffee(id++, if (v == null) "Alte ${b.name}" else "${b.name} «${v.brand}»", b.name, v?.emoji ?: b.emoji,
            tags, b.vol, baseIngs(b) + (v?.ings ?: emptyList()), steps, layers, v?.top, b.cold, v?.tags?.contains("Алкоголь") == true))
    }
    out
}
