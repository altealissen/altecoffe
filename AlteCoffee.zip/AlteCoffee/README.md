# AlteCoffee — приложение бариста
1. Создайте репозиторий на GitHub и загрузите ВСЁ содержимое папки (включая скрытую .github).
2. Вкладка Actions → Build APK → Run workflow (или push в main).
3. Когда сборка закончится, скачайте APK: Artifacts → AlteCoffee-apk.
